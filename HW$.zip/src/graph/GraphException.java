package graph;

public class GraphException extends Exception {
	public GraphException(String msg) {
		//sends msg to parent
		super(msg);
	}
}