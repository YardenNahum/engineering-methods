package graph;

public class Place {
	private int x;
	private int y;
	public Place(int x, int y, int bound) {
		//checks if x and y is in boundries of 0-(bound-1)
		if(x>bound-1 || x<0 || y<0 || y>bound-1)
			throw new IllegalArgumentException();
		this.x = x;
		this.y = y;
	}
	public int getX() {
		//returns x
		return x;
	}
	public int getY() {
		//returns y
		return y;
	}
	@Override
	public boolean equals(Object obj) {
		Place p;
		//checks if obj is instanceof Place type
		if(obj instanceof Place) {
			p = (Place) obj;
			//check equality of x and y values
			if(p.getX()==x&&p.getY()==y)
				return true;
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		//creating Hash Code
		int  hash =1;
		hash = 31 * hash + x;
		hash = 31 * hash +y;
		return hash; 
	}
}