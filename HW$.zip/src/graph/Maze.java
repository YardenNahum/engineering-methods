package graph;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Maze implements GraphInterface<Place> {
	private char [][] mArr;
	private Place start, end;
	
	public Maze(int size, int startx, int starty, int endx, int endy) {
		//set start\end positions
		start = new Place(startx,starty,size);
		end = new Place(endx,endy,size);
		//create maze
		mArr = new char[size][size];
		//set each position in maze as '.'
		for(int i=0;i<mArr[0].length;i++) {
			for(int j=0;j<mArr[0].length;j++) {
					mArr[i][j] ='.';
				}
			}
		//set start position as S and end position as E
		mArr[startx][starty]='S';
		mArr[endx][endy]='E';

	}
	public boolean addWall(int x, int y) {
		Place wall = new Place(x,y,mArr[0].length);
		//if we are at the start\end\position of an existing wall - return false, otherwise create a wall and return true
		if(wall.equals(end)||wall.equals(start)||mArr[y][x]=='@')
			return false;
		mArr[y][x] = '@';
		return true;
	}
	public String toString() {
	int i ,j;
	StringBuilder mazestr = new StringBuilder();
	//run on maze
	for(i=0;i<mArr[0].length;i++) {
		for(j=0;j<mArr[0].length;j++) {
			//add each location of the maze to its str representaion
			mazestr.append(mArr[i][j]);
		}
		mazestr.append("\n");
	}
	return mazestr.toString();
	}
	
	public boolean isSolvable() {
		Graph<Place> g = new Graph<>();
		//a list of the added places to the graph
		List<Place> added = new ArrayList<>();
		int i,j;
		//add vertices to graph
		for(i=0;i<mArr.length;i++) {
			for(j=0;j<mArr[i].length;j++) {
				//checks if the position is not a wall
				if(mArr[i][j]!='@') {
					Place p = new Place(i,j,mArr[0].length);
					try {
						//adds place to graph
						g.addVertex(p);
					} catch (GraphException e){
						e.printStackTrace();
					}
				}
			}
		}
		//add edges to graph
		for(i=0;i<mArr.length;i++) {
			for(j=0;j<mArr[i].length;j++) {
				//checks if position is not a wall
				if(mArr[i][j]!='@') {
					Place p = new Place(i,j,mArr[0].length);
					//check and add edges for valid neighbors
					added.add(p);
					if(i>0 && mArr[i-1][j] != '@') {
						Place left = new Place(i-1,j,mArr[0].length);
						//checks if left neighbor has already been connected with an edge to p
						if(!added.contains(left)) {
						try {
							
							g.addEdge(p, left);
						} catch (GraphException e) {
							e.printStackTrace();
						}
					}
						
				}
					if(i<mArr.length-1&&mArr[i+1][j]!='@') {
						Place right = new Place(i+1,j,mArr[0].length);
						//checks if right neighbor has already been connected with an edge to p
						if(!added.contains(right)) {
						try {
							g.addEdge(p, new Place(i+1,j,mArr[0].length));
						} catch (GraphException e) {
							e.printStackTrace();
						}
					}
				}
					if(j>0&&mArr[i][j-1]!='@') {
						Place top = new Place(i,j-1,mArr[0].length);
						//checks if top neighbor has already been connected with an edge to p
						if(!added.contains(top)) {
						try {
							g.addEdge(p, new Place(i,j-1,mArr[0].length));
						} catch (GraphException e) {
							e.printStackTrace();
						}
					}
				}
					if(j<mArr.length-1&&mArr[i][j+1]!='@') {
						Place bottom = new Place(i,j+1,mArr[0].length);
						//checks if bottom neighbor has already been connected with an edge to p
						if(!added.contains(bottom)) {
						try {
							g.addEdge(p, new Place(i,j+1,mArr[0].length));
						} catch (GraphException e) {
							e.printStackTrace();
						}
					}	
				}
	         }
	        }
		}
		try {
			//returns if the end and start point can connect in graph
			return g.connected(start, end);
	    }
		catch (GraphException e) {
	        e.printStackTrace();
	        return false;
		}
	}
	   
	@Override
	public Collection<Place> neighbours(Place v) {
		Collection<Place> nList = new ArrayList<>();
		int vX = v.getX();
		int vY = v.getY();
		//left neighbor
		if(vX>0&&mArr[vX-1][vY]!='@')
			nList.add(new Place(vX-1,vY,mArr[0].length));
		//right neighbor
		if(vX<mArr.length-1&&mArr[vX+1][vY]!='@')
			nList.add(new Place(vX+1,vY,mArr[0].length));
		//up neighbor
		if(vY>0&&mArr[vX][vY-1]!='@')
			nList.add(new Place(vX,vY-1,mArr[0].length));
		//down neighbor
		if(vY<mArr.length-1&&mArr[vX][vY+1]!='@')
			nList.add(new Place(vX,vY+1,mArr[0].length));
		return nList;
	}
}
	
