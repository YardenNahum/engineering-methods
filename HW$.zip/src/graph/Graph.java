package graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public class Graph<V> {
	private Set<V> vertices = new HashSet<>();
	private Map<V, Set<V>> edges = new HashMap<>();
	
	public void addVertex(V v) throws GraphException{
		//if the vertex already exists in vertices
		if(vertices.contains(v))
			throw new GraphException("The vertex already exsits.");
		//add v vertex to vertices
		vertices.add(v);
		//adds to edges an empty Set to v key
		edges.put(v, new HashSet<>());
	}
	public void addEdge(V v1, V v2) throws GraphException{
		//if v1 or v2 isnt contained in vertices
		if(!vertices.contains(v1)||!vertices.contains(v2))
			throw new GraphException("vertex  v1 or v2 doesnt exist.");	
		//if there is already an edge between v1 and v2
		if(hasEdge(v1, v2))
			throw new GraphException("edge of v1 and v2 already exists.");
		//create an edge between v1 and v2
		edges.get(v1).add(v2);
		edges.get(v2).add(v1);
	}
	public boolean hasEdge(V v1, V v2) {
		//if v1 isnt null and edges contains v2 element
		if(edges.containsKey(v1)&&edges.get(v1).contains(v2))
			return true;
		return false;
	}
	private boolean BFS(Set<V> visited,Queue<V> queue,V endV) {
		//end of search - vertex not found
		if(queue.isEmpty()) {
			return false;
		}
		//removes and gets the head of queue
		V current = queue.remove();
		//found end vertex
		if(current.equals(endV))
			return true;
		visited.add(current);
		for(V neighbor:edges.get(current)) {
			if(!visited.contains(neighbor)) {
				queue.add(neighbor);
				//mark as visited when added to queue
				visited.add(neighbor);
			}
		}
		//recursive call to BFS
		return BFS(visited, queue, endV);
	}
	
	public boolean connected(V v1, V v2) throws GraphException{
		Set<V> visited  = new HashSet<>();
		Queue<V> Q = new LinkedList<>();
		//if v1 or v2 isnt contained in vertices
		if(!vertices.contains(v1)||!vertices.contains(v2))
			throw new GraphException("vertex  v1 or v2 doesnt exist.");
		//if v1 equals to v2
		if(v1.equals(v2))
			return true;
		// BFS initializing
		Q.add(v1);
		return BFS(visited,Q,v2);
	}
}
