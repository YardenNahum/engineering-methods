package graph;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class ConnectionChecker<V>{
	private GraphInterface<V> g;

	public ConnectionChecker(GraphInterface<V> g) {
		//set maze graph
		this.g = g;
	} 
	private boolean BFS(Set<V> visited,Queue<V> queue,V endV) {
		//end of search - vertex not found
		if(queue.isEmpty()) {
			return false;
		}
		//removes and gets the head of queue
		V current = queue.remove();
		//found end vertex
		if(current.equals(endV))
			return true;
		//add current vertex to visited
		visited.add(current);
		//run on neighbors of current
		for(V neighbor: g.neighbours(current)) {
			//checks if visited does not contain neighbor
			if(!visited.contains(neighbor)) {
				queue.add(neighbor);
				//mark as visited when added to queue
				visited.add(neighbor);
			}
		}
		//recursive call to BFS
		return BFS(visited, queue, endV);
	}
	public boolean check(V v1, V v2) {
		Set<V> visited  = new HashSet<>();
		Queue<V> Q = new LinkedList<>();
		//if v1 equals to v2
		if(v1.equals(v2))
			return true;
		//add v1 to Q
		Q.add(v1);
		//return the result of BFS with relevant parameters
		return BFS(visited,Q,v2);
	}

}
