package equiv;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Equiv <E>{
	private List<Set<E>> list =new ArrayList<>();
	
	//adds e1 and e2 to the same equivalence class
	public void add(E e1, E e2) {
		int group1=-1,group2=-1,i;
		Set<E> class1=null,class2=null,temp;
		Set<E> newClass = new HashSet<>();
		//if e1 or e2 is null
		if(e1==null||e2==null)
			return;
		//if e1 is equal to e2 they are in the same equivalence class already
		if(e1.equals(e2))
			return;
		//runs on list and finds a class which contains e1 and a class which contains e2
		for(i=0;i<list.size();i++) {
			temp = list.get(i);
			//checks if e1 is contained in temp
			if(temp.contains(e1)) {
				group1 = i;
				class1 = temp;
			}
			//checks if e2 is contained in temp
			if(temp.contains(e2)) {
				group2 = i;
				class2 = temp;
			}
		}
		//if both classes does not exist - create a new equivalence class which contains e1 and e2
		if(class1==null&&class2==null) {
			newClass.add(e1);
			newClass.add(e2);
			list.add(newClass);
		}
		//if class1 is null - adds e1 to class2 and update class2 in list
		else if(class1==null&&class2!=null) {
			class2.add(e1);
			list.remove(group2);
			list.add(class2);
		}
		//if class2 is null - adds e2 to class1 and update class1 in list
		else if(class1!=null&&class2==null) {
			class1.add(e2);
			list.remove(group1);
			list.add(class1);
		}
		//if both classes exist - add all the content of class2 to class1, remove it from list and update class1 in list
		else {
			class1.addAll(class2);
			list.remove(group2);
			list.remove(group1);
			list.add(class1);
		}
	}
	
	public boolean are(E e1, E e2) {
		Set<E> class1=null;
		//if both e1 and e2 are null
		if(e1==null||e2==null)
			return false;
		//if e1 and e2 are in the same equivalence class
		if(e1.equals(e2))
			return true;
		//run on list and check if an equivalence class contains e1 and e2. return true if it does. otherwise return false
		for(Set<E> c: list) {
			if(c.contains(e1)) {
				class1 = c;
				if(class1.contains(e2))
					return true;
			}
		}
		return false;
	}
}
