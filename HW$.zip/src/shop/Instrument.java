package shop;

public abstract class Instrument {
	protected int price;
	protected String company;
	//counter for serial numbers
	private static int cntserial=0;
	private int serial;
	
	public Instrument(String company,int price) {
		this.company=company;
		this.price = price;
		serial = cntserial++;
	}
	
	public int getPrice() {
		//return instrument's price
		return price;
	}
	public String getCompany() {
		//return instrument's company name
		return company;
	}
	//implemented at each child class
	public abstract String toString() ;
	
	public int getSerial() {
		//returns serial number of an instrument
		return serial;
	}
}
