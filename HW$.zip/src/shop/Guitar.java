package shop;

public class Guitar extends Instrument{
	private Type type;
	
	public Guitar(String company, int price, Type type) {
		//sends parameters to parent
		super(company,price);
		this.type = type;
	}
	public Type getType() {
		//return the guitar type
		return type;
	}
	@Override
	public String toString() {
		//toString according to requested format
		return String.format("Guitar(%s) %s(%d), price = %d",type,company,getSerial(),price);
	}
	
}
