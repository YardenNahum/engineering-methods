package shop;

public class Piano extends Instrument {
	private int oct;
	public Piano(String company, int price, int octaves) {
		//sends parameters to parent
		super(company,price);
		oct = octaves;
	}
	public int getOctaves() {
		//return octave number
		return oct;
	}
	@Override
	public String toString() {
		//return string according to requested format
		return String.format("Piano(%d octaves) %s(%d), price = %d",oct,company,getSerial(),price);
	}
	
}
