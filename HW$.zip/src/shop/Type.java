package shop;

public enum Type {
	//enum guitar types
	ACOUSTIC, ELECTRIC, CLASSICAL;
	
	@Override
	public String toString() {
		//overrides tostring and returns strings according to enum guitar type as requested format
		switch(this) {
	    case ACOUSTIC:
	        return "Acoustic";
	    case ELECTRIC:
	        return "Electric";
	    default:
	        return "Classical";	
		}
	}
}
