package shop;

public class MusicShopException extends Exception {
	public MusicShopException(String msg) {
		super(msg);
	}
}
