package shop;

import java.util.ArrayList;
import java.util.List;

public class Shop {
	private List<Instrument> shopL = new ArrayList<>();
	
	public void add(Instrument i) {
		//adds a instrument to the end of the shop list
		shopL.add(i);
	}
	public Instrument get(int serial) {
		//runs on every instrument in the shop list
		for(Instrument i: shopL) {
			//checks if the current instrument's serial number is equal to the serial number we were given
			if(i.getSerial() == serial)
				//if it is return the instrument
				return i;
		}
		return null;
	}
	
	public List<Integer> allSerials(){
		List<Integer> serialList = new ArrayList<>();
		//runs on every instrument in the shop list
		for(Instrument i: shopL) {
			//add each instrument's serial number to serial list
			serialList.add(i.getSerial());
		}
		return serialList;
	}
	
	public List<Integer> guitarsOfType(Type t){
		List<Integer> serialList = new ArrayList<>();
		Guitar g;
		//runs on every instrument in the shop list
		for(Instrument i: shopL) {
			//if we meet an instanceof a guitar
			if(i instanceof Guitar) {
				g = (Guitar) i;
				//checks if the guitar is from the same type we were given
				if(g.getType().equals(t))
					//if it is - add its serial number
					serialList.add(i.getSerial());
			}
		}
		return serialList;
	}
	
	public void sell(int serial) throws MusicShopException {
	    Instrument instrument = this.get(serial);
	    int guitarCount=0;
	    if(instrument==null)
	    	throw new MusicShopException("The item is not in stock.");
	    //checks if the instrument is a guitar
	    if(instrument instanceof Guitar) {
	    	for(Instrument i: shopL) {
	    		if(i instanceof Guitar)
	    			guitarCount++;
	    	}
		    //if theres only guitar in stock and we are trying to sell it - throw an exception
		    if(guitarCount==1)
		    	throw new MusicShopException("Only 1 guitar in stock - not for sale.");
	    }
	    //removes the instrument from the shop list
	    shopL.remove(instrument);
	}
	
	public int sellAll(int[] serials) {
		int NotSold =0;
		//runs on every serial number in serials
		for(int s: serials) {
			//sell s
			try {
				this.sell(s);
			}
			//catches exception
			catch (MusicShopException e){
				System.out.println(e.getMessage());
				//updates NotSold instruments counter
				NotSold++;
			}
		}
		return NotSold;
	}
}