package cities;

public class City implements Comparable<City> {
	private String name;
	private Country country;
	private int population;
	
	public City(String name, Country country, int population) {
		this.name = name;
		this.country = country;
		this.population = population;
	}
	//returns a city's name
	public String getName() {
		return name;
	}
	//returns a city's country
	public Country getCountry() {
		return country;
	}
	//returns a city's population
	public int getPopulation() {
		return population;
	}
	
	@Override
	public int compareTo(City o) {
		//if the given city is equal to city return 0, otherwise return the compareto result of the two
		if(this.equals(o))
			return 0;
	return this.name.compareTo(o.getName());
	}
	//returns string according to requested format
	public String toString() {
		return String.format("%s (of %s)", name,country);
	}
	
	@Override
	public boolean equals(Object city) {
		City c;
		//checks if city is instanceof City
		if(city instanceof City) {
			//casting to City type
			c = (City) city;
			//checks if the country of city is equal to the country of c
			if(c.getCountry().equals(this.country))
				//checks if city name is equal to c name
				if(c.getName().equals(this.name))
					return true;
		}
		return false;
	}
}
