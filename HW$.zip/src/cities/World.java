package cities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class World {
	private Map<String, Country> countries = new HashMap<>();
	
	public void addCountry(String name) {
		//creates a new country with the given name
		Country c = new Country(name);
		//add it to countries hashmap
		countries.put(name, c);
	}
	public void addCity(String name, String countryName, int population) {
		City c;
		//check if the given country name exists in countries
		if(countries.containsKey(countryName))
		{
			//create a new city
			c = new City(name, countries.get(countryName), population);
			//add it to cities hashmap
			countries.get(countryName).addCity(c);
		}
		else
			throw new IllegalArgumentException();
	}
	public int population() {
		int sumPop = 0;
		//run on countries values and sum all countries population
		for(Country i: countries.values()) {
			sumPop += i.population();
		}
		return sumPop;
	}
	public List<City> smallCities(int under){
		//create new arraylist
		List<City> list = new ArrayList<>();
		//run on countries values and add to list every city that has a population below under
		for(Country i: countries.values()) {
			list.addAll(i.smallCities(under));
		}
		//sort list
		Collections.sort(list);
		return list;
	}
	public String report() {
		StringBuilder worldstr = new StringBuilder();
		//run on countries values and add to stringbuilder each country's report
		for(Country i: countries.values()) {
			worldstr.append(i.report());
			worldstr.append("\n");
			}
		//append to stringbuilder the population sum of all countries
		worldstr.append("Total population is ");
		worldstr.append(this.population());
		worldstr.append("\n");
		return worldstr.toString();
		}
}
