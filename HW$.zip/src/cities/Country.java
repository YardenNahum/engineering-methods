package cities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Country implements Comparable<Country> {
	private Set<City> cities= new TreeSet<>();
	private String name;
	//sets country name
	public Country(String name) {
		this.name = name;
	}
	public void addCity(City city){
		//if a city is already in cities array throw exception, if it isnt - add it
		if(!city.getCountry().toString().equals(name))
			throw new IllegalArgumentException();
		cities.add(city);
	}
	public int population() {
		int popSum = 0;
		//run on cities and sum the population of all of them
		for(City c: cities) {
			popSum += c.getPopulation();
		}
		return popSum;
	}
	public List<City> smallCities(int under){
		List<City> list = new ArrayList<>();
		//run on cities and check if a city's population is smaller than under
		for(City c: cities) {
			//if it is - add it to list
			if(c.getPopulation()<under)
				list.add(c);
		}
		//sort list
		Collections.sort(list);
		return list;
	}
	public String report() {
		//stringbuilder according to requested format
		StringBuilder rep = new StringBuilder();
		rep.append(name);
		rep.append("(");
		rep.append(this.population());
		rep.append(") : ");	
		//get from each city its name and population and add them to stringbuilder
		for(City c: cities) {
			rep.append(c.getName());
			rep.append("(");
			rep.append(c.getPopulation());
			rep.append("), ");
		}
		//deletes last "," and " "
		rep.deleteCharAt(rep.length()-1);
		rep.deleteCharAt(rep.length()-1);
		return rep.toString();
	}
	@Override
	public boolean equals(Object country) {
		Country c;
		//check if country is an instanceof Country type
		if(country instanceof Country) {
			c = (Country) country;
			//if the country name is equal to the given country name return true, otherwise false
			if(this.name.equals(c.toString()))
				return true;
		}
		return false;
	}

	@Override
	public int compareTo(Country o) {
		//check if country is equal to the given country. if it is return 0, otherwise return the compareTo result of the two
		if(this.equals(o))
			return 0;
		return this.name.compareTo(o.toString());
	}
	public String toString() {
		//return country name string
		return name;
	}
}
